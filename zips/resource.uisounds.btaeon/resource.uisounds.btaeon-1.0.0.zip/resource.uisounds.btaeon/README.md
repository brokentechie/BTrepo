# Brokentechie: Aeon Nox Mod
UI Sounds for Brokentechie Build v7.0

## License
The Brokentechie: Aeon Nox Mod and all its contents are licensed under the GPLv3 License. It is open source software which is free to use. Modifications to the UI Sounds may be made so as long as accreditation is provided to me. Any modified version of this software must also be licensed under GPLv3.

### How to Use
Install, then enjoy!

Brokentechie: Aeon Nox Mod is Free and Open Source Software.

